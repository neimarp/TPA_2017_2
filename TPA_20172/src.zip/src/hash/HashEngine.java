
package hash;


public interface HashEngine {
    public int hashCode(Object k);//
}
