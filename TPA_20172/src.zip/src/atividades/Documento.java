package atividades;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Documento {

    public Documento(String arquivo) {
        this.nomeArq = arquivo;
    }

    void imprime(ArrayList lista) {
        System.out.println("quantidade de palavras = " + lista.size());
        for (Object lista1 : lista) {
            System.out.println(lista1);
        }
    }

    ArrayList<String> lerArquivo(String arquivo) {
        ArrayList lista = new ArrayList();

        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader("c:/arquivo.html"));
            while (br.ready()) {
                String linha = br.readLine();
                System.out.println(linha);
            }
            br.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Documento.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Documento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }

    String nomeArq;

    //retorna uma lista com as palavras do texto
    public ArrayList palavras() {
        ArrayList lista = new ArrayList();

        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader(nomeArq));
            while (br.ready()) {
                String linha = br.readLine();
                String[] split = linha.split("[\\s,.()]");
                for (String palavra : split) {
                    //System.out.println(palavra);
                    if(!palavra.isEmpty())
                        lista.add(palavra);
                }
                System.out.println(linha);
            }
            br.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Documento.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Documento.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }

    //retorna uma lista de ngramas do tamanho tam
    public ArrayList ngramas(int tam) {
        ArrayList listaPalavras = palavras();
        ArrayList listaNgramas = new ArrayList();
        
        for(int i =0 ; i<= listaPalavras.size()-tam;i++){
            String strNgrama = "";
            for (int j = 0; j < tam; j++) {
                strNgrama = strNgrama+","+listaPalavras.get(i+j);
            }
            listaNgramas.add(strNgrama.substring(1, strNgrama.length()));
        }
        
        return listaNgramas;
    }

    //retorna uma lista do tipo tabela frequencia ngramas
    public ArrayList freqNgramas(int tam) {
        ArrayList listaNgrama = ngramas(2);
       
        return null;
    }
    
    public static void main(String[] args) {
        Documento doc = new Documento("texto.txt");

        ArrayList lista = doc.ngramas(2);
        doc.imprime(lista);
    }
}
